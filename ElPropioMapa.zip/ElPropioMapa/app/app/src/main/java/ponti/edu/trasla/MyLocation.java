package ponti.edu.trasla;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;

public class MyLocation {
    public double lat;
    public double longs;
    public Date fecha;
    public MyLocation() {}

    public JSONObject toJSON () {
        JSONObject obj = new JSONObject();
        try {
            obj.put("latitud", getLatitud());
            obj.put("longitud", getLongitud());
            obj.put("fecha",getFecha());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return obj;
    }

    private String getFecha() {
        return String.valueOf(fecha);
    }

    private String getLongitud() {
        return String.valueOf(longs);
    }

    private String getLatitud() {
        return String.valueOf(lat);
    }
}

package ponti.edu.trasla;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OSMActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_osmactivity);
    }
}